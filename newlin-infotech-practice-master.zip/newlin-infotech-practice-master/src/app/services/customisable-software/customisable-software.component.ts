import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customisable-software',
  templateUrl: './customisable-software.component.html',
  styleUrls: ['./customisable-software.component.css']
})
export class CustomisableSoftwareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
