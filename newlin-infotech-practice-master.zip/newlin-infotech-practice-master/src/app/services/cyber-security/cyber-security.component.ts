import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cyber-security',
  templateUrl: './cyber-security.component.html',
  styleUrls: ['./cyber-security.component.css']
})
export class CyberSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
