import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infrastructure-solution',
  templateUrl: './infrastructure-solution.component.html',
  styleUrls: ['./infrastructure-solution.component.css']
})
export class InfrastructureSolutionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
