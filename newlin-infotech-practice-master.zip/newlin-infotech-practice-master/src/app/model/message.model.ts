export interface Message {
    salutation?: string
    fname?: string,
    lname?: string,
    email?: string,
    phoneNumber?: string,
    ourServices?: string,
    message?: string,
    timestamp?: Date
}