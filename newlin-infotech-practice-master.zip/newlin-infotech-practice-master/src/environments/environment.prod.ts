export const environment = {
  production: true,
  BrandName: 'Newlin Infotech',
  baseUrl: 'https://us-central1-newlininfotech-dc00e.cloudfunctions.net/'
};
